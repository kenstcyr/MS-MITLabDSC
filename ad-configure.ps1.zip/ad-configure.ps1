﻿$people =   [tuple]::Create("Alice", "Anderson", "aanderson"),
            [tuple]::Create("Bruce", "Blackford", "bblackford"),
            [tuple]::Create("Chris", "Cassidy", "ccassidy"),
            [tuple]::Create("Darren", "Davis", "ddavis"),
            [tuple]::Create("Eleanor", "Evans", "eevans"),
            [tuple]::Create("Fred", "Franklin", "ffranklin"),
            [tuple]::Create("Gary", "Garrison", "ggarrison"),
            [tuple]::Create("Hugh", "Harris", "hharris"),
            [tuple]::Create("Irma", "Iverson", "iiverson"),
            [tuple]::Create("Jane", "Jackson", "jjackson")

$svcaccts =   [tuple]::Create("AIP", "Scanner", "srv_aipscan"),
			  [tuple]::Create("SQL", "Service", "sqlsvc")
 

configuration AD
{
    param
    (
        [Parameter(Mandatory)][PSCredential]$DomainCred,
        [Parameter(Mandatory)][String]$DomainName,
        [Parameter(Mandatory)][String]$DomainNetBIOSName,
        [Parameter(Mandatory)][String]$DomainDN,
        [Parameter(Mandatory)][String]$CompanyName,
        [Parameter(Mandatory)][String]$SCCMFilesURL,
        [Parameter(Mandatory)][String]$SCCMFilesUserName,
        [Parameter(Mandatory)][String]$SCCMFilesKey

    )

    Import-DscResource -ModuleName xActiveDirectory
    Import-DscResource -ModuleName xSystemSecurity
    Import-DscResource -ModuleName xAdcsDeployment
    Import-DscResource -ModuleName xTimeZone
    Import-DscResource -ModuleName xStorage
    Import-DscResource -ModuleName xDnsServer
    
    node "localhost"
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'Apply'
            RebootNodeIfNeeded = $true
            AllowModuleOverwrite = $true
        }
        xTimeZone PacificTZ
        {
            IsSingleInstance = 'Yes'
            TimeZone = 'Pacific Standard Time'
        }
        xIEEsc DisableIEESCAdmins
        {
            UserRole = 'Administrators'
            isEnabled = $false
        }
        xIEEsc DisableIEESCUsers
        {
            UserRole = 'Users'
            isEnabled = $false
        }
        Script IESettings
        {
            SetScript = {
				if ((Test-Path "HKCU:\SOFTWARE\Microsoft\Internet Explorer\Main") -eq $false) 
				{ 
					New-Item -Path "HKCU:\SOFTWARE\Microsoft\Internet Explorer\Main" -Force
				}
				if ((Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3") -eq $false) 
				{ 
					New-Item -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Force
				}
				
				New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Internet Explorer\Main" -Name "Start Page" -Value "about:blank" -Force
                New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Name "2500" -Value "3" -PropertyType DWORD -Force
				New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3" -Name "1803" -Value "0" -PropertyType DWORD -Force
			}
            TestScript = { $false }
            GetScript = { }
        }
        xDisk DataDrive
        {
            DiskId = 2
            DriveLetter = 'N'
            FSFormat = 'NTFS'
            FSLabel = 'NTDS'
        }
        WindowsFeature ADDSInstall
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }
        WindowsFeature InstallDhcpServerTools
        {
            Ensure = "Present"
            Name = "RSAT-DHCP"
        }
        xADDomain ADConfiguration
        {
            DomainName = $DomainName
            DomainNetbiosName = $DomainNetBIOSName
            DomainAdministratorCredential = $DomainCred
            SafemodeAdministratorPassword = $DomainCred
            DatabasePath = 'N:\NTDS'
            LogPath = 'N:\NTDS'
            SysvolPath = 'N:\SYSVOL'
            DependsOn = "[WindowsFeature]ADDSInstall",'[xDisk]DataDrive'
        }
        xADOrganizationalUnit ADOURoot
        {
            Name = $CompanyName
            Path = $DomainDN
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[xADDomain]ADConfiguration'
        }
        xADOrganizationalUnit ADOUPeople
        {
            Name = 'People'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[xADOrganizationalUnit]ADOURoot'
        }
        xADOrganizationalUnit ADOUGroups
        {
            Name = 'Groups'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[xADOrganizationalUnit]ADOURoot'
        }
        xADOrganizationalUnit ADOUServiceAccounts
        {
            Name = 'Service Accounts'
            Path = "OU=$CompanyName,$DomainDN"
            ProtectedFromAccidentalDeletion = $false
            Credential = $DomainCred
            DependsOn = '[xADOrganizationalUnit]ADOURoot'
        }
        
        
        # Create Test Users
        foreach ($person in $people)
        {
            xADUser "User$person.GetHashCode().ToString()"
            {
                DomainName = $DomainName
                UserName = $person.Item3
                UserPrincipalName = "$($person.Item3)@$DomainName"
                DisplayName = "$($person.Item1) $($person.Item2)"
                Password = $DomainCred
                Path = "OU=People,OU=$CompanyName,$DomainDN"
                PasswordNeverExpires = $true
                GivenName = $person.Item1
                Surname = $person.Item2
                JobTitle = "Employee"
                Company = $CompanyName
                Country = "US"
                DependsOn = '[xADOrganizationalUnit]ADOUPeople'
            }
        }

        # Create Service Accounts
        foreach ($svcacct in $svcaccts)
        {
            xADUser "ServiceAccount$svcacct.GetHashCode().ToString()"
            {
                DomainName = $DomainName
                UserName = $svcacct.Item3
                UserPrincipalName = "$($svcacct.Item3)@$DomainName"
                DisplayName = "$($svcacct.Item1) $($svcacct.Item2)"
                Password = $DomainCred
                Path = "OU=Service Accounts,OU=$CompanyName,$DomainDN"
                PasswordNeverExpires = $true
                GivenName = $svcacct.Item1
                Surname = $svcacct.Item2
                JobTitle = "Service Account"
                Company = $CompanyName
                Country = "US"
                DependsOn = '[xADOrganizationalUnit]ADOUServiceAccounts'
            }
        }

        xADGroup ProjectMoonshoot
        {
            GroupName = 'ProjectMoonshoot'
            DisplayName = "Project Moonshoot"
            GroupScope = 'Universal'
            Category = 'Security'
            Path = "OU=Groups,OU=$CompanyName,$DomainDN"
            Credential = $DomainCred
            MembersToInclude = $people[0].Item3, $people[3].Item3, $people[7].Item3
            DependsOn = '[xADOrganizationalUnit]ADOUGroups'
        }
        
        WindowsFeature ADCSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Certificate"
            DependsOn = '[xADDomain]ADConfiguration'                                 
        }
		WindowsFeature ADCSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADCS"             
        }
        xAdcsCertificationAuthority ADCSConfiguration
        {
            Ensure = 'Present'
            CAType = 'EnterpriseRootCA'
            Credential = $DomainCred
            DependsOn = '[WindowsFeature]ADCSInstall'
        }

        xDnsRecord LitWarePortalRecord
        {
            Name = "portal"
            Zone = $DomainName
            Target = "10.1.0.12"
            Type = "ARecord"
            Ensure = "Present"
            DependsOn = '[xADDomain]ADConfiguration'
        }

        xDnsRecord LitWareExpensesRecord
        {
            Name = "expenses"
            Zone = $DomainName
            Target = "10.1.0.12"
            Type = "ARecord"
            Ensure = "Present"
            DependsOn = '[xADDomain]ADConfiguration'
        }
		
		Script CreateSCCMSysMgmtContainer
        {
            SetScript = {
				$SysContainer = [ADSI]("LDAP://CN=System," + ([ADSI]"").distinguishedName)
				try { $null = $SysContainer.Children.Find("CN=System Management") }
				catch { ($SysContainer.Create("Container", "CN=System Management")).SetInfo() }
            }
            TestScript = { 
				try { 
					$null = ([ADSI]("LDAP://CN=System," + ([ADSI]"").distinguishedName)).Children.Find("CN=System Management")
					$true
				}
				catch { $false }
			}
            GetScript = { }
			Credential = $DomainCred
            DependsOn = '[xADDomain]ADConfiguration'
        }
		File CreateFolderSCCM
		{
			Ensure = "Present"
			Type = "Directory"
			DestinationPath = "$($env:SystemDrive)\SCCM"
		}
		Script CopySCCMInstallFiles
        {
            SetScript = {
                net use Z: $SCCMFilesURL /u:$SCCMFilesUserName $SCCMFilesKey /persistent:no
				robocopy Z:\AutoPSInst\SCCM1810 C:\SCCM /MIR /MT:128
			}
            TestScript = { Test-Path "$($env:SystemDrive)\SCCM\*" }
            GetScript = { }
			DependsOn = "[File]CreateFolderSCCM"
        }
		Script ExtendSchemaForSCCM
        {
            SetScript = {
                cmd /C "$($env:SystemDrive)\SCCM\SMSSETUP\bin\X64\extadsch.exe"
				New-Item -Path 'c:\temp\schema.completed' -ItemType File -Force
			}
            TestScript = { Test-Path "c:\temp\schema.completed" }
            GetScript = { }
            Credential = $DomainCred
			DependsOn = "[Script]CopySCCMInstallFiles",'[xADDomain]ADConfiguration'
        }
    }
}